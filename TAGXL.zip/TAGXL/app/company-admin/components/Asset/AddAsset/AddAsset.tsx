"use client";

import React, { useState } from "react";
import Step1 from "./Step1";
import Step4 from "./Step4";
import Step3 from "./Step3";
import Step2 from "./Step2";
import { useRouter } from "next/navigation";
import { createAsset } from "@/app/services/company-admin/asset-actions";

const AddAsset = () => {
    const router = useRouter();

    const [currentStep, setCurrentStep] = useState(1);

    const [formData, setFormData] = useState({
        tag_type: "",
        uid: "",
        tag_id: "",
        name: "",
        location_id: "",
        batch_code: "",
        // image: null as File | null,
        image: "",
        manual_template_id: "",
        status: null,
        // oem_certificate: null as File | null,
        oem_certificate: "",
        // third_party_certificate: null as File | null,
        third_party_certificate: "",
        third_party_start_date: "",
        third_party_expiry_date: "",
        pre_use_template_id: "",
        maintenance_template_id: "",
        asset_pre_use_questions: "",
        asset_maintenance_questions: "",
    });

    const [errors, setErrors] = useState<any>({});
    const [formError, setFormError] = useState("");

    const updateForm = function (name: string, value: any) {
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
        if (errors[name]) {
            setErrors((prev: any) => ({ ...prev, [name]: "" }));
        }
    };

    const handleSave = async function () {
        // const data = formData
        // console.log(data)

        const assetFormData = new FormData();
        assetFormData.append("tag_id", formData.tag_id);
        assetFormData.append("name", formData.name);
        assetFormData.append("location_id", formData.location_id);
        assetFormData.append("batch_code", formData.batch_code);
        formData.image && assetFormData.append("image", formData.image);
        formData.manual_template_id && assetFormData.append("manual_template_id", formData.manual_template_id);
        assetFormData.append("status", String(Number(formData.status) || 0));
        assetFormData.append("oem_certificate", formData.oem_certificate);
        if (formData.third_party_certificate) {
            assetFormData.append("third_party_certificate", formData.third_party_certificate);
            assetFormData.append("third_party_start_date", formData.third_party_start_date);
            assetFormData.append("third_party_expiry_date", formData.third_party_expiry_date);
        }
        assetFormData.append("pre_use_template_id", formData.pre_use_template_id);
        assetFormData.append("maintenance_template_id", formData.maintenance_template_id);
        formData.asset_pre_use_questions &&
            assetFormData.append("asset_pre_use_questions", formData.asset_pre_use_questions);
        formData.asset_maintenance_questions &&
            assetFormData.append("asset_maintenance_questions", formData.asset_maintenance_questions);

        console.log([...assetFormData.entries()]);

        const response = await createAsset(assetFormData);

        console.log("response for create asset: ", response);

        if (response.success) {
            router.push("/company-admin/asset?create=true");
            return;
        }

        if (!response.success && response.error) {
            setFormError(response.error);
        }
    };

    const requiredFields = ["tag_id", "name", "location_id", "batch_code", "oem_certificate"];

    const validate = function () {
        const newErrors: any = {};

        if (currentStep === 1) {
            // if (!formData.tag_id) newErrors.tag_id = "Tag id is required";
            if (!formData.tag_type) newErrors.tag_type = "Select the Tag Type is required";
            if (!formData.uid) newErrors.uid = "Tag uid is required";
        }

        if (currentStep === 2) {
            if (!formData.name) newErrors.name = "Name is required";
            if (!formData.location_id) newErrors.location_id = "Location is required";
            if (!formData.batch_code) newErrors.batch_code = "Batch code is required";
        }

        if (currentStep === 3) {
            if (!formData.oem_certificate) newErrors.oem_certificate = "OEM Certificate is required";
            if (formData.third_party_certificate) {
                if (!formData.third_party_start_date)
                    newErrors.third_party_start_date = "Third party start date required";
                if (!formData.third_party_expiry_date)
                    newErrors.third_party_expiry_date = "Third party expiry date required";
            }
            if (
                (formData.third_party_start_date || formData.third_party_expiry_date) &&
                !formData.third_party_certificate
            ) {
                newErrors.third_party_certificate = "Third party certificate is required";
            }
        }

        if (currentStep === 4) {
            if (!formData.pre_use_template_id) newErrors.pre_use_template_id = "Select the pre use template";
            if (!formData.maintenance_template_id) newErrors.maintenance_template_id = "Select the maintenance template";
        }

        setErrors(newErrors);

        return Object.keys(newErrors).length === 0;
    };

    const nextStep = () => {
        setCurrentStep((prevStep) => prevStep + 1);
    };

    const prevStep = () => {
        setCurrentStep((prevStep) => prevStep - 1);
    };

    return (
        <>
            {currentStep === 1 && (
                <Step1
                    next={nextStep}
                    updateForm={updateForm}
                    validate={validate}
                    errors={errors}
                    formData={formData}
                />
            )}

            {currentStep === 2 && (
                <Step2
                    prev={prevStep}
                    next={nextStep}
                    updateForm={updateForm}
                    validate={validate}
                    errors={errors}
                    formData={formData}
                />
            )}

            {currentStep === 3 && (
                <Step3
                    prev={prevStep}
                    next={nextStep}
                    updateForm={updateForm}
                    validate={validate}
                    errors={errors}
                    formData={formData}
                />
            )}

            {currentStep === 4 && (
                <Step4
                    prev={prevStep}
                    next={nextStep}
                    updateForm={updateForm}
                    validate={validate}
                    errors={errors}
                    formData={formData}
                    handleSubmit={handleSave}
                    formError={formError}
                />
            )}
        </>
    );
};

export default AddAsset;
